	<meta charset="utf-8" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $ROOT; ?>assets/img/emsoft.ico"  />

	<link rel="stylesheet" type="text/css" href="<?php echo $ROOT; ?>assets/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo $ROOT; ?>assets/css/style.css" />
	<!-- <link rel = "stylesheet" type = "text/css" href = "../assets/style.css" /> -->

	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />


	<script src="<?php echo $ROOT; ?>assets/js/jquery-3.5.1.min.js"></script>
	<script src="<?php echo $ROOT; ?>assets/js/bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
